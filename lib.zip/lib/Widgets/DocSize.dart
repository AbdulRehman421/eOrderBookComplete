class DocSize {
  String format, width, height;

  DocSize(this.format, this.width, this.height);

  String get getFormat => format;

  String get getWidth => width;

  String get getHeight => height;
}
